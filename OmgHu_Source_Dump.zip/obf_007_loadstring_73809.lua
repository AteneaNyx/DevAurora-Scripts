local Settings, Connections = ...

local _ENV = (getgenv or getrenv or getfenv)()

if type(Settings) ~= "table" or type(Connections) ~= "table" then
	return {}
end

local VirtualInputManager: VirtualInputManager = game:GetService("VirtualInputManager")
local CollectionService: CollectionService = game:GetService("CollectionService")
local ReplicatedStorage: ReplicatedStorage = game:GetService("ReplicatedStorage")
local TeleportService: TeleportService = game:GetService("TeleportService")
local RunService: RunService = game:GetService("RunService")
local Players: Players = game:GetService("Players")

local Remotes = ReplicatedStorage:WaitForChild("Remotes")
local GunValidator: RemoteEvent = Remotes:WaitForChild("Validator2")
local CommF: RemoteFunction = Remotes:WaitForChild("CommF_")
local CommE: RemoteEvent = Remotes:WaitForChild("CommE")

local ChestModels: Folder = workspace:WaitForChild("ChestModels")
local WorldOrigin: Folder = workspace:WaitForChild("_WorldOrigin")
local Characters: Folder = workspace:WaitForChild("Characters")
local SeaBeasts: Folder = workspace:WaitForChild("SeaBeasts")
local Enemies: Folder = workspace:WaitForChild("Enemies")
local Boats: Folder = workspace:WaitForChild("Boats")
local Map: Model = workspace:WaitForChild("Map")

local EnemySpawns: Folder = WorldOrigin:WaitForChild("EnemySpawns")
local Locations: Folder = WorldOrigin:WaitForChild("Locations")

local RenderStepped = RunService.RenderStepped
local Heartbeat = RunService.Heartbeat
local Stepped = RunService.Stepped
local Player = Players.LocalPlayer

local Data: Folder = Player:WaitForChild("Data")
local Level: IntValue = Data:WaitForChild("Level")
local Fragments: IntValue = Data:WaitForChild("Fragments")
local Money: IntValue = Data:WaitForChild("Beli")

local Modules: Folder? = ReplicatedStorage:WaitForChild("Modules")
local Net: ModuleScript = Modules:WaitForChild("Net")

local EXECUTOR_NAME = string.upper(if identifyexecutor then identifyexecutor() else "NULL")
local IS_BLACKLISTED_EXECUTOR = table.find({"NULL", "XENO", "SWIFT", "JJSPLOIT"}, EXECUTOR_NAME)

local hookmetamethod = (not IS_BLACKLISTED_EXECUTOR and hookmetamethod) or (function(...) return ... end)
local hookfunction = (not IS_BLACKLISTED_EXECUTOR and hookfunction) or (function(...) return ... end)
local sethiddenproperty: (Instance, string, any?) -> (nil) = sethiddenproperty or (function(...) return ... end)

local setupvalue: (any, number, any?) -> (nil) = setupvalue or (debug and debug.setupvalue)
local getupvalue: (any, number) -> any = getupvalue or (debug and debug.getupvalue)

local BRING_TAG: string = _ENV._Bring_Tag or `b{math.random(80, 2e4)}t`
local KILLAURA_TAG: string = _ENV._KillAura_Tag or `k{math.random(120, 2e4)}t`

local HIDDEN_SETTINGS: { [string]: any } = {
	SKILL_COOLDOWN = 0.5,
	CLEAR_AFTER = 50
}

_ENV._Bring_Tag = BRING_TAG
_ENV._KillAura_Tag = KILLAURA_TAG

local function GetEnemyName(string: string): string
	return (string:find("Lv. ") and string:gsub(" %pLv. %d+%p", "") or string):gsub(" %pBoss%p", "")
end

local function CheckPlayerAlly(__Player: Player): boolean
	if tostring(__Player.Team) == "Marines" and __Player.Team == Player.Team then
		return false
	elseif __Player:HasTag(`Ally{Player.Name}`) or Player:HasTag(`Ally{__Player.Name}`) then
		return false
	end
	
	return true
end

local function WaitChilds(Instance, ...)
	for _, ChildName in ipairs({...}) do
		Instance = Instance:WaitForChild(ChildName)
	end
	return Instance
end

local function FastWait(Seconds, Instance, ...)
	local Success, Result = pcall(function(...)
		for _, ChildName in ipairs({...}) do
			Instance = Instance:WaitForChild(ChildName, Seconds)
		end
		return Instance
	end, ...)
	
	return Success and Result or nil
end

local function CreateNewClear()
	local COUNT_NEWINDEX = 0
	
	return {
		__newindex = function(self, index, value)
			if COUNT_NEWINDEX >= HIDDEN_SETTINGS.CLEAR_AFTER then
				for key, cache in pairs(self) do
					if typeof(cache) == "Instance" and not cache:IsDescendantOf(game) then
						rawset(self, key, nil)
					end
				end
				COUNT_NEWINDEX = 0
			end
			
			COUNT_NEWINDEX += 1
			return rawset(self, index, value)
		end
	}
end

function CreateDictionary(array: { string }, value: any?): { [string]: any? }
	local Dictionary = {}
	
	for _, string in ipairs(array) do
		Dictionary[string] = if type(value) == "table" then {} else value
	end
	
	return Dictionary
end

local Signal = {} do
	local Connection = {} do
		Connection.__index = Connection
		
		function Connection:Disconnect(): (nil)
			if not self.Connected then
				return nil
			end
			
			local find = table.find(self.Signal, self)
			
			if find then
				table.remove(self.Signal, find)
			end
			
			self.Function = nil
			self.Connected = false
		end
		
		function Connection:Fire(...): (nil)
			if not self.Function then
				return nil
			end
			
			task.spawn(self.Function, ...)
		end
		
		function Connection.new(): Connection
			return setmetatable({
				Connected = true
			}, Connection)
		end
		
		setmetatable(Connection, {
			__index = function(self, index)
				error(("Attempt to get Connection::%s (not a valid member)"):format(tostring(index)), 2)
			end,
			__newindex = function(tb, key, value)
				error(("Attempt to set Connection::%s (not a valid member)"):format(tostring(key)), 2)
			end
		})
	end
	
	Signal.__index = Signal
	
	function Signal:Connect(Function): Connection
		if type(Function) ~= "function" then
			return nil
		end
		
		local NewConnection = Connection.new()
		NewConnection.Function = Function
		NewConnection.Signal = self
		
		table.insert(self.Connections, NewConnection)
		return NewConnection
	end
	
	function Signal:Once(Function): (nil)
		local Connection;
		Connection = self:Connect(function(...)
			Function(...)
			Connection:Disconnect()
		end)
		return Connection
	end
	
	function Signal:Wait(): any?
		local WaitingCoroutine = coroutine.running()
		local Connection;Connection = self:Connect(function(...)
			Connection:Disconnect()
			task.spawn(WaitingCoroutine, ...)
		end)
		return coroutine.yield()
	end
	
	function Signal:Fire(...): (nil)
		for _, Connection in ipairs(self.Connections) do
			if Connection.Connected then
				Connection:Fire(...)
			end
		end
	end
	
	function Signal.new(): Signal
		return setmetatable({
			Connections = {}
		}, Signal)
	end
	
	setmetatable(Signal, {
		__index = function(self, index)
			error(`Attempt to get Signal::{ tostring(index) } (not a valid member)`, 2)
		end,
		__newindex = function(self, index, value)
			error(`Attempt to set Signal::{ tostring(index) } (not a valid member)`, 2)
		end
	})
end

if table.find({2753915549, 85211729168715, 113741252407134, 114279672983750}, game.PlaceId) then
    SeaId = 1
elseif table.find({4442272183, 79091703265657}, game.PlaceId) then
    SeaId = 2
elseif table.find({7449423635, 100117331123089}, game.PlaceId) then
    SeaId = 3
end

local LevelCap = game.Players.LocalPlayer:GetAttribute("LevelCap")
if LevelCap and LevelCap > 2800 and LevelCap <= 3000 then
    LevelCap = 2800
end

local Module = {} do
	local Cached = {
		Closest = nil,
		Equipped = nil,
		Humanoids = setmetatable({}, CreateNewClear()),
		Enemies = {}, -- setmetatable({}, CreateNewClear()),
		Progress = {},
		Bring = {},
		Tools = {}
	}
	
	Module.GameData = {
		Sea = SeaId,
		SeasName = { "Main", "Dressrosa", "Zou" },
		MaxMastery = 600,
		MaxLevel = LevelCap,
        StringVersion = require(ReplicatedStorage.BuildInfo).VERSION
	}
	
	Module.Debounce = {
		TargetDebounce = 0,
		UpdateDebounce = 0,
		GetEnemy = 0,
		Skills = {}
	}
	
	do
		Module.FruitsId = {
			["rbxassetid://15124425041"] = "Rocket",
			["rbxassetid://15123685330"] = "Spin",
			["rbxassetid://15123613404"] = "Blade",
			["rbxassetid://15123689268"] = "Spring",
			["rbxassetid://15123595806"] = "Bomb",
			["rbxassetid://15123677932"] = "Smoke",
			["rbxassetid://15124220207"] = "Spike",
			["rbxassetid://121545956771325"] = "Flame",
			["rbxassetid://15123673019"] = "Sand",
			["rbxassetid://15123618591"] = "Dark",
			["rbxassetid://77885466312115"] = "Eagle",
			["rbxassetid://15112600534"] = "Diamond",
			["rbxassetid://15123640714"] = "Light",
			["rbxassetid://15123668008"] = "Rubber",
			["rbxassetid://15123662036"] = "Ghost",
			["rbxassetid://15123645682"] = "Magma",
			["rbxassetid://15123606541"] = "Quake",
			["rbxassetid://15123606541"] = "Buddha",
			["rbxassetid://15123643097"] = "Love",
			["rbxassetid://15123681598"] = "Spider",
			["rbxassetid://116828771482820"] = "Creation",
			["rbxassetid://15123679712"] = "Sound",
			["rbxassetid://15123654553"] = "Phoenix",
			["rbxassetid://15123656798"] = "Portal",
			["rbxassetid://15123670514"] = "Rumble",
			["rbxassetid://15123652069"] = "Pain",
			["rbxassetid://15123587371"] = "Blizzard",
			["rbxassetid://15123633312"] = "Gravity",
			["rbxassetid://15123648309"] = "Mammoth",
			["rbxassetid://15694681122"] = "T-Rex",
			["rbxassetid://15123624401"] = "Dough",
			["rbxassetid://15123675904"] = "Shadow",
			["rbxassetid://10773719142"] = "Venom",
			["rbxassetid://15123616275"] = "Control",
			["rbxassetid://11911905519"] = "Spirit",
			["rbxassetid://15123638064"] = "Leopard",
			["rbxassetid://15487764876"] = "Kitsune",
			["rbxassetid://115276580506154"] = "Yeti",
			["rbxassetid://118054805452821"] = "Gas",
			["rbxassetid://95749033139458"] = "Dragon East"
		}

       CACHE_NPC_LIST = require(game.ReplicatedStorage.GuideModule).Data.NPCList
function getQuestPosition(Name)
    for _, v in next, CACHE_NPC_LIST do
        if typeof(v) == "table" then
            for _, x in next, v do
                if x == Name then
                    local Position = v.Position
                    if typeof(Position) == "CFrame" then
                        return Position
                    elseif typeof(Position) == "Vector3" then
                        return CFrame.new(Position)
                    end
                end
            end
        end
    end
    return nil
end
		
		if SeaId == 1 then
    Module.Bosses = {
        ["Saber Expert"] = {
            NoQuest = true,
            Position = game:GetService("ReplicatedStorage").FortBuilderReplicatedSpawnPositionsFolder["Saber Expert"].CFrame
        },

        ["The Saw"] = {
            RaidBoss = true,
            Position = game:GetService("ReplicatedStorage").FortBuilderReplicatedSpawnPositionsFolder["The Saw"].CFrame
        },

        ["Greybeard"] = {
            RaidBoss = true,
            Position = game:GetService("ReplicatedStorage").FortBuilderReplicatedSpawnPositionsFolder["Greybeard"].CFrame
        },

        ["The Gorilla King"] = {
            IsBoss = true,
            Level = 20,
            Position = game:GetService("ReplicatedStorage").FortBuilderReplicatedSpawnPositionsFolder["The Gorilla King"].CFrame,
            Quest = {"JungleQuest", getQuestPosition("JungleQuest")}
        },

        ["Bobby"] = {
            IsBoss = true,
            Level = 55,
            Position = game:GetService("ReplicatedStorage").FortBuilderReplicatedSpawnPositionsFolder["Chef"].CFrame,
            Quest = {"BuggyQuest1", getQuestPosition("BuggyQuest1")}
        },

        ["Yeti"] = {
            IsBoss = true,
            Level = 105,
            Position = game:GetService("ReplicatedStorage").FortBuilderReplicatedSpawnPositionsFolder["Yeti"].CFrame,
            Quest = {"SnowQuest", getQuestPosition("SnowQuest")}
        },

        ["Vice Admiral"] = {
            IsBoss = true,
            Level = 130,
            Position = game:GetService("ReplicatedStorage").FortBuilderReplicatedSpawnPositionsFolder["Vice Admiral"].CFrame,
            Quest = {"MarineQuest2", getQuestPosition("MarineQuest2"), 2}
        },
        ["Warden"] = {
            IsBoss = true,
            Level = 220,
            Position = game:GetService("ReplicatedStorage").FortBuilderReplicatedSpawnPositionsFolder["Warden"].CFrame,
            Quest = {"ImpelQuest", getQuestPosition("ImpelQuest"), 2}
        },

        ["Magma General"] = {
            IsBoss = true,
            Level = 350,
            Position = game:GetService("ReplicatedStorage").FortBuilderReplicatedSpawnPositionsFolder["Magma Admiral"].CFrame,
            Quest = {"MagmaQuest", getQuestPosition("MagmaQuest")}
        },

        ["Fishman Lord"] = {
            IsBoss = true,
            Level = 425,
            Position = game:GetService("ReplicatedStorage").FortBuilderReplicatedSpawnPositionsFolder["Fishman Lord"].CFrame,
            Quest = {"FishmanQuest", getQuestPosition("FishmanQuest")}
        },

        ["Sky Warlord"] = {
            IsBoss = true,
            Level = 500,
            Position = game:GetService("ReplicatedStorage").FortBuilderReplicatedSpawnPositionsFolder["Wysper"].CFrame,
            Quest = {"SkyExp1Quest", getQuestPosition("SkyExp1Quest"), 3}
        },

        ["Lightning God"] = {
            IsBoss = true,
            Level = 575,
            Position = game:GetService("ReplicatedStorage").FortBuilderReplicatedSpawnPositionsFolder["Thunder God"].CFrame,
            Quest = {"SkyExp2Quest", getQuestPosition("SkyExp2Quest"), 3}
        },

        ["Cyborg"] = {
            IsBoss = true,
            Level = 675,
            Position = game:GetService("ReplicatedStorage").FortBuilderReplicatedSpawnPositionsFolder["Cyborg"].CFrame,
            Quest = {"FountainQuest", getQuestPosition("FountainQuest")}
        }
    }

elseif SeaId == 2 then
    Module.Bosses = {
        ["Don Swan"] = {
            RaidBoss = true,
            Position = CFrame.new(2289, 15, 808)
        },

        ["Cursed Captain"] = {
            RaidBoss = true,
            Position = CFrame.new(912, 186, 33591)
        },

        ["Darkbeard"] = {
            RaidBoss = true,
            Position = CFrame.new(3695, 13, -3599)
        },

        ["Diamond"] = {
            IsBoss = true,
            Level = 750,
            Position = CFrame.new(-1569, 199, -31),
            Quest = {"Area1Quest", CFrame.new(-427, 73, 1835)}
        },

        ["Jeremy"] = {
            IsBoss = true,
            Level = 850,
            Position = CFrame.new(2316, 449, 787),
            Quest = {"Area2Quest", CFrame.new(635, 73, 919)}
        },

        ["Orbitus"] = {
            IsBoss = true,
            Level = 925,
            Position = CFrame.new(-2086, 73, -4208),
            Quest = {"MarineQuest3", CFrame.new(-2441, 73, -3219)}
        },

        ["Smoke Admiral"] = {
            IsBoss = true,
            Level = 1150,
            Position = CFrame.new(-5078, 24, -5352),
            Quest = {"IceSideQuest", CFrame.new(-6229, 82, -4853)}
        },

        ["Awakened Ice Admiral"] = {
            IsBoss = true,
            Level = 1400,
            Position = CFrame.new(6473, 297, -6944),
            Quest = {"FrostQuest", CFrame.new(5668, 28, -6484)}
        },

        ["Tide Keeper"] = {
            IsBoss = true,
            Level = 1475,
            Position = CFrame.new(-3711, 77, -11469),
            Quest = {"ForgottenQuest", CFrame.new(-3056, 240, -10145)}
        }
    }

elseif SeaId == 3 then
    Module.Bosses = {
        ["Tyrant of the Skies"] = {
            RaidBoss = true,
            Position = CFrame.new(-16252, 153, 1394)
        },

        ["Cake Prince"] = {
            RaidBoss = true,
            Position = CFrame.new(-2103, 70, -12165)
        },

        ["Dough King"] = {
            RaidBoss = true,
            Position = CFrame.new(-2103, 70, -12165)
        },

        ["rip_indra True Form"] = {
            RaidBoss = true,
            Position = CFrame.new(-5333, 424, -2673)
        },

        ["Stone"] = {
            IsBoss = true,
            Level = 1550,
            Position = CFrame.new(-1049, 40, 6791),
            Quest = {"PiratePortQuest", CFrame.new(-449, 109, 5950)}
        },

        ["Hydra Leader"] = {
            IsBoss = true,
            Level = 1675,
            Position = CFrame.new(5836, 1019, -83),
            Quest = {"VenomCrewQuest", CFrame.new(5214, 1004, 761)}
        },

        ["Kilo Admiral"] = {
            IsBoss = true,
            Level = 1750,
            Position = CFrame.new(2904, 509, -7349),
            Quest = {"MarineTreeIsland", CFrame.new(2485, 74, -6788)}
        },

        ["Captain Elephant"] = {
            IsBoss = true,
            Level = 1875,
            Position = CFrame.new(-13393, 319, -8423),
            Quest = {"DeepForestIsland", CFrame.new(-13233, 332, -7626)}
        },

        ["Beautiful Pirate"] = {
            IsBoss = true,
            Level = 1950,
            Position = CFrame.new(5370, 22, -89),
            Quest = {"DeepForestIsland2", CFrame.new(-12682, 391, -9901)}
        },

        ["Cake Queen"] = {
            IsBoss = true,
            Level = 2175,
            Position = CFrame.new(-710, 382, -11150),
            Quest = {"IceCreamIslandQuest", CFrame.new(-818, 66, -10964)}
        },

        ["Longma"] = {
            NoQuest = true,
            Position = CFrame.new(-10218, 333, -9444)
        }
    }
end
		
		Module.Shop = {
            --[[{"Magic Elf", {{"Buy 2x EXP", {"Candies", "Buy", 1, 1}}, {"Buy Stats Refund", {"Candies", "Buy", 1, 2}}, {"Buy Race Reroll", {"Candies", "Buy", 1, 3}}}},
            {"Greedy Elf", {{"Buy 200 Fragments", {"Candies", "Buy", 2, 1}}, {"Buy 500 Fragments", {"Candies", "Buy", 2, 2}}}},
            {"Santa Claws", {{"Buy Elf Hat", {"Candies", "Buy", 3, 1}}, {"Buy Santa Hat", {"Candies", "Buy", 3, 2}}, {"Buy Sleigh", {"Candies", "Buy", 3, 3}}}},]]
			{"Frags", {{"Race Reroll", {"BlackbeardReward", "Reroll", "2"}}, {"Reset Stats", {"BlackbeardReward", "Refund", "2"}}}},
			{"Ability Teacher", {
				{"Buy Geppo", {"BuyHaki", "Geppo"}},
				{"Buy Buso", {"BuyHaki", "Buso"}},
				{"Buy Soru", {"BuyHaki", "Soru"}},
				{"Buy Ken", {"KenTalk", "Buy"}}
			}},
			{"Sword", {
				{"Buy Katana", {"BuyItem", "Katana"}},
				{"Buy Cutlass", {"BuyItem", "Cutlass"}},
				{"Buy Dual Katana", {"BuyItem", "Dual Katana"}},
				{"Buy Iron Mace", {"BuyItem", "Iron Mace"}},
				{"Buy Triple Katana", {"BuyItem", "Triple Katana"}},
				{"Buy Pipe", {"BuyItem", "Pipe"}},
				{"Buy Dual-Headed Blade", {"BuyItem", "Dual-Headed Blade"}},
				{"Buy Soul Cane", {"BuyItem", "Soul Cane"}},
				{"Buy Bisento", {"BuyItem", "Bisento"}}
			}},
			{"Gun", {
				{"Buy Musket", {"BuyItem", "Musket"}},
				{"Buy Slingshot", {"BuyItem", "Slingshot"}},
				{"Buy Flintlock", {"BuyItem", "Flintlock"}},
				{"Buy Refined Slingshot", {"BuyItem", "Refined Slingshot"}},
				{"Buy Dual Flintlock", {"BuyItem", "Dual Flintlock"}},
				{"Buy Cannon", {"BuyItem", "Cannon"}},
				{"Buy Kabucha", {"BlackbeardReward", "Slingshot", "2"}}
			}},
			{"Accessories", {
				{"Buy Black Cape", {"BuyItem", "Black Cape"}},
				{"Buy Swordsman Hat", {"BuyItem", "Swordsman Hat"}},
				{"Buy Tomoe Ring", {"BuyItem", "Tomoe Ring"}},
                {"Buy Ghoul Mask", {"Ectoplasm", "Buy", 2}}
			}},
			{"Race", {{"Ghoul Race", {"Ectoplasm", "Change", 4}}, {"Cyborg Race", {"CyborgTrainer", "Buy"}}}}
		}
	end
	
	do
		Module.IsSuperBring = false
		
		Module.RemoveCanTouch = 0
		Module.AttackCooldown = 0
		Module.PirateRaid = 0
		
		Module.Webhooks = true
		Module.JobIds = true
		
		Module.Progress = {}
		Module.EnemyLocations = {}
		Module.SpawnLocations = {}
		
		Module.Cached = Cached
	end
	
	Module.Signals = {} do
		local Signals = Module.Signals
		
		Signals.PossibleStaff = Signal.new()
		Signals.OptionChanged = Signal.new()
		Signals.EnemyAdded = Signal.new()
		Signals.EnemyDied = Signal.new()
		Signals.Notify = Signal.new()
	end
	
	Module.RunFunctions = {} do
		Module.RunFunctions.Translator = function(Window, Translation)
			local MakeTab = Window.MakeTab
			
			Window.MakeTab = function(self, Configs)
				if Translation[ Configs[1] ] then
					Configs[1] = Translation[ Configs[1] ]
				end
				
				local Tab = MakeTab(self, Configs)
				local NewTab = {}
				
				function NewTab:AddSection(Name)
					return Tab:AddSection(Translation[Name] or Name)
				end
				
				function NewTab:AddButton(Configs)
					local Translator = Translation[ Configs[1] ]
					
					if Translator then
						Configs[1] = type(Translator) == "string" and Translator or Translator[1]
						Configs.Desc = type(Translator) ~= "string" and Translator[2]
					end
					
					return Tab:AddButton(Configs)
				end
				
				function NewTab:AddToggle(Configs)
					local Translator = Translation[ Configs[1] ]
					
					if Translator then
						Configs[1] = type(Translator) == "string" and Translator or Translator[1]
						Configs.Desc = type(Translator) ~= "string" and Translator[2]
					end
					
					return Tab:AddToggle(Configs)
				end
				
				function NewTab:AddSlider(Configs)
					local Translator = Translation[ Configs[1] ]
					
					if Translator then
						Configs[1] = type(Translator) == "string" and Translator or Translator[1]
						Configs.Desc = type(Translator) ~= "string" and Translator[2]
					end
					
					return Tab:AddSlider(Configs)
				end
				
				function NewTab:AddDropdown(Configs)
					local Translator = Translation[ Configs[1] ]
					
					if Translator then
						Configs[1] = type(Translator) == "string" and Translator or Translator[1]
						Configs.Desc = type(Translator) ~= "string" and Translator[2]
					end
					
					return Tab:AddDropdown(Configs)
				end
				
				function NewTab:AddTextBox(Configs)
					local Translator = Translation[ Configs[1] ]
					
					if Translator then
						Configs[1] = type(Translator) == "string" and Translator or Translator[1]
						Configs.Desc = type(Translator) ~= "string" and Translator[2]
					end
					
					return Tab:AddTextBox(Configs)
				end
				
				for i,v in pairs(Tab) do
					if not NewTab[i] then
						NewTab[i] = v
					end
				end
				
				return NewTab
			end
		end

     Module.RunFunctions.Quests = function(self, QuestsModule, getTasks)
			local MaxLvl = ({ {0, 700}, {700, 1500}, {1500, LevelCap} })[self.Sea]
			local bl_Quests = {"BartiloQuest", "MarineQuest", "CitizenQuest"}
			
			for name, task in QuestsModule do
				if table.find(bl_Quests, name) then continue end
				
				for num, mission in task do
					local Level = mission.LevelReq
					if Level >= MaxLvl[1] and Level < MaxLvl[2] then
						local target, positions = getTasks(mission)
						table.insert(self.QuestList, {
							Name = name,
							Count = num,
							Enemy = { Name = target, Level = Level, Position = positions }
						})
					end
				end
			end
			
			table.sort(self.QuestList, function(v1, v2) return v1.Enemy.Level < v2.Enemy.Level end)
		end
		
		Module.RunFunctions.LibraryToggle = function(EnabledOptions, Options)
			return function(...)
				local Tab, Settings, Flag = ...
				
				Options[Flag] = Tab:AddToggle({
					Settings[1],																				 -- Name
					type(Settings[2]) ~= "string" and Settings[2],			 -- Default
					function(Value) EnabledOptions[Flag] = Value end,		-- Callback
					Flag,																								-- Flag
					Desc = (type(Settings[2]) == "string" and Settings[2]) or Settings[3]
				})
			end
		end
		
      Module.RunFunctions.FarmQueue = function(Options)
    local function GetQueue()
        for _, Option in Options do
            Settings.RunningOption = Option.Name
            local Method = Option.Function()
            if Method then
                if type(Method) == "string" then
                    Settings.RunningMethod = Method
                end
                return Method
            end
        end
        Settings.RunningOption, Settings.RunningMethod = nil, nil
    end
    spawn(function()
        while task.wait(Settings.SmoothMode and 0.25 or 0) do
            pcall(function()
                if _ENV.teleporting then
                    _ENV.OnFarm = true
                else
                    _ENV.OnFarm = GetQueue() and true or false
                end
            end)
        end
    end)
end
	end
	
	function Module.FireRemote(...)
		return CommF:InvokeServer(...)
	end
	
	function Module.IsAlive(Character)
		if Character then
			local Humanoids = Cached.Humanoids
			local Humanoid = Humanoids[Character] or Character:FindFirstChild("Humanoid")
			
			if not Humanoid and Character.Parent == Boats then
				return true
			elseif Character.Parent == SeaBeasts then
				Humanoid = Character:FindFirstChild("Health")
			end
			
			if Humanoid then
				if not Humanoids[Character] then
					Humanoids[Character] = Humanoid
				end
				
				return Humanoid[if Humanoid.ClassName == "Humanoid" then "Health" else "Value"] > 0
			end
		end
	end
   
   local function DistanceFromCharacter(Value: CFrame | BasePart): number
	return Player:DistanceFromCharacter(Value.Position)
   end
	
	function Module.KillAura(Distance: number?, Name: string?): (nil)
		Distance = Distance or 500
		
		local EnemyList = Enemies:GetChildren()
		
		for i = 1, #EnemyList do
			local Enemy = EnemyList[i]
			local PrimaryPart = Enemy.PrimaryPart
			
			if (not Name or Enemy.Name == Name) and PrimaryPart and not Enemy:HasTag(KILLAURA_TAG) then
				if Module.IsAlive(Enemy) and Player:DistanceFromCharacter(PrimaryPart.Position) < Distance then
					Enemy:AddTag(KILLAURA_TAG)
				end
			end
		end
	end
	
	function Module.IsBoss(Name: string): boolean
		return Module.Bosses[Name] and true or false
	end

	function Module.Rejoin()
		 local ServerBrowser = ReplicatedStorage.__ServerBrowser 
         task.spawn(ServerBrowser.InvokeServer, ServerBrowser, "teleport", game.JobId)
	end

   function Module:ServerHop(bO)
       if not bO then
        bO = 10
    end
    ticklon = tick()
    repeat
        task.wait()
    until tick() - ticklon >= 1
    local function Hop()
        for r = 1, math.huge do
            local bP = game:GetService("ReplicatedStorage").__ServerBrowser:InvokeServer(r)
            for k, v in pairs(bP) do
                if k ~= game.JobId and v["Count"] < bO then
                   game:GetService("ReplicatedStorage").__ServerBrowser:InvokeServer("teleport", k)
                end
            end
        end
        return false
    end
    if not getgenv().Loaded then
        local function bQ(v)
            if v.Name == "ErrorPrompt" then
                if v.Visible then
                    if v.TitleFrame.ErrorTitle.Text == "Teleport Failed" then
                        HopServer()
                        v.Visible = false
                    end
                end
                v:GetPropertyChangedSignal("Visible"):Connect(
                    function()
                        if v.Visible then
                            if v.TitleFrame.ErrorTitle.Text == "Teleport Failed" then
                                HopServer()
                                v.Visible = false
                            end
                        end
                    end
                )
            end
        end
        for k, v in pairs(game.CoreGui.RobloxPromptGui.promptOverlay:GetChildren()) do
            bQ(v)
        end
        game.CoreGui.RobloxPromptGui.promptOverlay.ChildAdded:Connect(bQ)
        getgenv().Loaded = true
    end
    while not Hop() do
        wait()
    end
  end
	
	function Module.EnemySpawned(EnemyName)
		local Enemies = Module.Enemies
		return if type(EnemyName) == "table" then Enemies:GetClosest(EnemyName) else Enemies:GetEnemyByTag(EnemyName)
	end
	
	function Module:IsBlacklistedExecutor(): boolean
		return IS_BLACKLISTED_EXECUTOR
	end
	
	function Module:TravelTo(Sea: number?): (nil)
		Module.FireRemote(`Travel{self.GameData.SeasName[Sea]}`)
	end

	function Module.EquipTool(ToolName: string, ByType: boolean?): (nil)
		ByType = if not ToolName then true else ByType
		ToolName = ToolName or Settings.FarmTool
		
		if not Module.IsAlive(Player.Character) then
			return nil
		end
		
		local Equipped = Cached.Equipped
		
		if Equipped and Equipped.Parent and Equipped[if ByType then "ToolTip" else "Name"] == ToolName then
			if Equipped:GetAttribute("Locks") then
				Equipped:SetAttribute("Locks", nil)
			end
			
			if Equipped.Parent == Player.Backpack then
				Player.Character.Humanoid:EquipTool(Equipped)
			elseif Equipped.Parent == Player.Character then
				return nil
			end
		end
		
		if ToolName and not ByType then
			local BackpackTool = Player.Backpack:FindFirstChild(ToolName)
			
			if BackpackTool then
				Cached.Equipped = BackpackTool
				Player.Character.Humanoid:EquipTool(BackpackTool)
			end
		else
			for _, Tool in Player.Backpack:GetChildren() do
				if Tool:IsA("Tool") and Tool.ToolTip == ToolName then
					Cached.Equipped = Tool
					Player.Character.Humanoid:EquipTool(Tool)
					return nil
				end
			end
		end
	end

 function Module:BringEnemies(ToEnemy: Instance, SuperBring: boolean?): (nil)
    if not self.IsAlive(ToEnemy) or not ToEnemy.PrimaryPart then
      return nil
    end
    
    if Settings.BringMobs then
      Module.IsSuperBring = if SuperBring then true else false
      
      local Name = ToEnemy.Name
      local Position = (Player.Character or Player.CharacterAdded:Wait()):GetPivot().Position
      local Target = ToEnemy.PrimaryPart.CFrame
      local BringPositionTag = if SuperBring then "ALL_MOBS" else Name
      
      if not Cached.Bring[BringPositionTag] or (Target.Position - Cached.Bring[BringPositionTag].Position).Magnitude > 25 then
        Cached.Bring[BringPositionTag] = Target
      end
      
      local EnemyList = (not SuperBring and self.Enemies:GetTagged(Name)) or Enemies:GetChildren()
      
      for i = 1, #EnemyList do
        local Enemy = EnemyList[i]
        if Enemy.Parent ~= Enemies or Enemy:HasTag(BRING_TAG) then continue end
        if not Enemy:FindFirstChild("CharacterReady") then continue end
        
        local PrimaryPart = Enemy.PrimaryPart
        if self.IsAlive(Enemy) and PrimaryPart then
          if (Position - PrimaryPart.Position).Magnitude < Settings.BringDistance then
            Enemy:AddTag(BRING_TAG)
          end
        end
      end
    else
      if not Cached.Bring[ToEnemy] then
        Cached.Bring[ToEnemy] = ToEnemy.PrimaryPart.CFrame
      end
      
      ToEnemy.PrimaryPart.CFrame = Cached.Bring[ToEnemy]
    end
  end

	function Module:GetRaidIsland(): Instance?
		if Cached.RaidIsland and Cached.RaidIsland:IsDescendantOf(Locations) then
			return Cached.RaidIsland
		end
		
		for i = 5, 1, -1 do
			local Name = "Island " .. i
			for _, Island in ipairs(Locations:GetChildren()) do
				if Island.Name == Name and Player:DistanceFromCharacter(Island.Position) < 3500 then
					Cached.RaidIsland = Island
					return Island
				end
			end
		end
	end
	
	function Module:GetProgress(Tag, ...)
		local Progress = Cached.Progress
		local entry = Progress[Tag]
		
		if entry and (tick() - entry.debounce) < 2 then
			return entry.result
		end
		
		local result = self.FireRemote(...)
		
		if entry then
			entry.result = result
			entry.debounce = tick()
		else
			Progress[Tag] = {
				debounce = tick(),
				result = result
			}
		end
		
		return result
	end
	
	function Module:RemoveVolcanoLava()
		local PrehistoricIsland = Map.PrehistoricIsland
		
		if PrehistoricIsland.Core:FindFirstChild("InteriorLava") then
			PrehistoricIsland.Core.InteriorLava:Destroy()
		end
		
		for _, Instance in PrehistoricIsland:GetDescendants() do
			if string.find(string.lower(Instance.Name), "lava") and Instance:IsA("BasePart") then
				Instance:Destroy()
			end
		end
	end
	
	function Module:RemoveBoatCollision(Boat)
		local Objects = Boat:GetDescendants()
		
		for i = 1, #Objects do
			local BasePart = Objects[i]
			if BasePart:IsA("BasePart") and BasePart.CanCollide then
				BasePart.CanCollide = false
			end
		end
	end
	
	Module.Chests = setmetatable({}, {
		__call = function(self, SelectedIsland)
			local CachedChest = self.Cached
			
			if CachedChest and not CachedChest:GetAttribute("IsDisabled") then
				if not SelectedIsland or CachedChest:IsDescendantOf(SelectedIsland) then
					return CachedChest
				end
			end
			
			if self.Debounce and (tick() - self.Debounce) < 0.5 then
				return nil
			end
			
			local Position = (Player.Character or Player.CharacterAdded:Wait()):GetPivot().Position
			local Chests = CollectionService:GetTagged("_ChestTagged")
			
			local Distance, Nearest = math.huge
			
			for i = 1, #Chests do
				local Chest = Chests[i]
				local Magnitude = (Chest:GetPivot().Position - Position).Magnitude
				
				if not SelectedIsland or Chest:IsDescendantOf(SelectedIsland) then
					if not Chest:GetAttribute("IsDisabled") and Magnitude < Distance then
						Distance, Nearest = Magnitude, Chest
					end
				end
			end
			
			self.Debounce = tick()
			self.Cached = Nearest
			return Nearest
		end
	})
	
	Module.Berry = setmetatable({}, {
		__call = function(self, BerryArray)
			local CachedBush = self.Cached
			
			if CachedBush and CachedBush:IsDescendantOf(Map) then
				for Tag, CFrame in pairs(CachedBush:GetAttributes()) do
					return CachedBush
				end
			end
			
			if self.Debounce and (tick() - self.Debounce) < 0.5 then
				return nil
			end
			
			local Position = (Player.Character or Player.CharacterAdded:Wait()):GetPivot().Position
			local BerryBush = CollectionService:GetTagged("BerryBush")
			
			local Distance, Nearest = math.huge
			
			for i = 1, #BerryBush do
				local Bush = BerryBush[i]
				
				for AttributeName, BerryName in pairs(Bush:GetAttributes()) do
					if not BerryArray or table.find(BerryArray, BerryName) then
						local Magnitude = (Bush.Parent:GetPivot().Position - Position).Magnitude
						
						if Magnitude < Distance then
							Nearest, Distance = Bush, Magnitude
						end
					end
				end
			end
			
			self.Debounce = tick()
			self.Cached = Nearest
			return Nearest
		end
	})

   Module.FruitsName = setmetatable({}, {
    __index = function(self, Fruit)
        if typeof(Fruit) ~= "Instance" or not Fruit.Parent then
            return "Fruit [ ??? ]"
        end

        local RealFruitsName = Module.FruitsId
        local Name = Fruit.Name

        if Name ~= "Fruit " then
            rawset(self, Fruit, Name)
            return Name
        end

        rawset(self, Fruit, "Fruit [ ??? ]")

        task.spawn(function()
            pcall(function()
                if not Fruit.Parent then return end
                local Model = Fruit:WaitForChild("Fruit", 5)
                if not Model or not Fruit.Parent then return end
                local Idle = FastWait(2, Model, "Idle") or FastWait(1, Model, "Animation") or FastWait(1, Model, "Fruit")
                if Idle and (Idle:IsA("Animation") or Idle:IsA("MeshPart")) and Fruit.Parent then
                    local Property = if Idle:IsA("MeshPart") then "MeshId" else "AnimationId"
                    local RealName = RealFruitsName[Idle[Property] or ""]
                    if RealName and type(RealName) == "string" then
                        rawset(self, Fruit, `Fruit [ {RealName} ]`)
                    end
                end
            end)
        end)

        return "Fruit [ ??? ]"
    end
})

Module.Enemies = (function()
		local EnemiesModule = CreateDictionary({
			"__CakePrince", "__RaidBoss", "__TyrantSkies", "__Bones", "__Elite", "__Others", 
		}, {})
		
		local Signals = Module.Signals
        local IsAlive = Module.IsAlive

		local TagsMobs = {
			__Elite = CreateDictionary({ "Deandre", "Diablo", "Urban" }, true),
			__Bones = CreateDictionary({ "Living Zombie", "Demonic Soul", "Posessed Mummy" }, true),
			__CakePrince = CreateDictionary({ "Head Baker", "Baking Staff", "Cake Guard", "Cookie Crafter" }, true),
			__TyrantSkies = CreateDictionary({ "Sun-kissed Warrior", "Skull Slayer", "Isle Champion", "Serpent Hunter" }, true)
		}
		
		local Attachment = Instance.new("Attachment") do
			local AlignPosition = Instance.new("AlignPosition")
			AlignPosition.Mode = Enum.PositionAlignmentMode.OneAttachment
			AlignPosition.Position = Vector3.new(0, 20, 0)
			AlignPosition.Responsiveness = 200
			AlignPosition.MaxForce = math.huge
			AlignPosition.Parent = Attachment
			AlignPosition.Attachment0 = Attachment
		end

       local function New(list, NewEnemy)
			if table.find(list, NewEnemy) then return end
			
			local Humanoid = NewEnemy:WaitForChild("Humanoid")
			
			if Humanoid and Humanoid.ClassName == "Humanoid" and Humanoid.Health > 0 then
				table.insert(list, NewEnemy)
				Humanoid.Died:Wait()
				table.remove(list, table.find(list, NewEnemy))
			end
		end
		
		local function NewEnemyAdded(Enemy)
			local EnemyName = Enemy.Name
			local Others = EnemiesModule.__Others
			
			Others[EnemyName] = Others[EnemyName] or {}
			task.spawn(New, Others[EnemyName], Enemy)
			
			if Enemy:GetAttribute("RaidBoss") then
				task.spawn(New, EnemiesModule.__RaidBoss, Enemy)
			elseif EnemiesModule[`__{ EnemyName }`] then
				task.spawn(New, EnemiesModule[`__{ EnemyName }`], Enemy)
			else
				for Tag, Mobs in pairs(TagsMobs) do
					if Mobs[EnemyName] then
						task.spawn(New, EnemiesModule[Tag], Enemy)
						break
					end
				end
			end
		end
		
		function EnemiesModule.IsSpawned(EnemyName: string): boolean
			local Cached = Module.SpawnLocations[EnemyName]
			
			if Cached and Cached.Parent then
				return (Cached:GetAttribute("Active") or EnemiesModule:GetEnemyByTag(EnemyName)) and true or false
			end
			
			return EnemiesModule:GetEnemyByTag(EnemyName) and true or false
		end
		
		function EnemiesModule:GetTagged(TagName: string): table?
			return self[`__{TagName}`] or self.__Others[TagName]
		end
		
		function EnemiesModule:GetEnemyByTag(TagName: string): Model?
			local CachedEnemy = Cached.Enemies[TagName]
			
			if CachedEnemy and IsAlive(CachedEnemy) then
				return CachedEnemy
			end
			
			local Enemies = self:GetTagged(TagName)
			
			if Enemies and #Enemies > 0 then
				for i = 1, #Enemies do
					local Enemy = Enemies[i]
					
					if IsAlive(Enemy) then
						Cached.Enemies[TagName] = Enemy
						return Enemy
					end
				end
			end
		end
		
		function EnemiesModule:GetClosest(Enemies: table): Model?
			local SpecialTag = table.concat(Enemies, ".")
			local CachedEnemy = Cached.Enemies[SpecialTag]
			
			if CachedEnemy and IsAlive(CachedEnemy) then
				return CachedEnemy
			end
			
			local Distance, Nearest = math.huge
			
			for i = 1, #Enemies do
				local Enemy = self:GetClosestByTag(Enemies[i])
				local Magnitude = Enemy and Player:DistanceFromCharacter(Enemy.PrimaryPart.Position)
				
				if Enemy and Magnitude <= Distance then
					Distance, Nearest = Magnitude, Enemy
				end
			end
			
			if Nearest then
				Cached.Enemies[SpecialTag] = Nearest
				return Nearest
			end
		end
		
		function EnemiesModule:GetClosestByTag(TagName: string): Model?
			local CachedEnemy = Cached.Enemies[TagName]
			
			if CachedEnemy and IsAlive(CachedEnemy) then
				return CachedEnemy
			end
			
			local Enemies = self:GetTagged(TagName)
			
			if Enemies and #Enemies > 0 then
				local Distance, Nearest = math.huge
				
				local Position = (Player.Character or Player.CharacterAdded()):GetPivot().Position
				
				for i = 1, #Enemies do
					local Enemy = Enemies[i]
					local PrimaryPart = Enemy.PrimaryPart
					
					if PrimaryPart and IsAlive(Enemy) then
						local Magnitude = (Position - PrimaryPart.Position).Magnitude
						
						if Magnitude <= 15 then
							Cached.Enemies[TagName] = Enemy
							return Enemy
						elseif Magnitude <= Distance then
							Distance, Nearest = Magnitude, Enemy
						end
					end
				end
				
				if Nearest then
					Cached.Enemies[TagName] = Nearest
					return Nearest
				end
			end
		end
		
		function EnemiesModule:CreateNewTag(Tag: string, Enemies: table): table?
			local NewTag = {}
			self[`__{Tag}`] = NewTag
			
			for i = 1, #Enemies do
				self[`__{Enemies[i]}`] = NewTag
				local Others = self.__Others[ Enemies[i] ]
				
				if Others then
					for i = 1, #Others do
						task.spawm(newEnemy, NewTag, Others[i])
					end
				end
			end
			
			return NewTag
		end
		
		local function Bring(Enemy)
local PlayerRootPart = (Player.Character or Player.CharacterAdded()):WaitForChild("HumanoidRootPart")
      local RootPart = Enemy:WaitForChild("HumanoidRootPart")
      local Humanoid = Enemy:WaitForChild("Humanoid")
      local EnemyName = Enemy.Name

      sethiddenproperty(game.Players.LocalPlayer, "SimulationRadius", 112412400000)
      sethiddenproperty(game.Players.LocalPlayer, "MaxSimulationRadius", 112412400000)
      
      local BodyPosition = Instance.new("BodyPosition", RootPart)
      BodyPosition.Position = RootPart.Position
      BodyPosition.P, BodyPosition.D = 3e4, 3e3
      BodyPosition.MaxForce = Vector3.new(math.huge, math.huge, math.huge)
      
      while PlayerRootPart and RootPart and Humanoid and Humanoid.Health > 0 and Enemy and Enemy.Parent == Enemies and Enemy:HasTag(BRING_TAG) do
        local Target = Cached.Bring[if Module.IsSuperBring then "ALL_MOBS" else EnemyName]
        
        if Target and (PlayerRootPart.Position - RootPart.Position).Magnitude <= Settings.BringDistance then
       if _ENV.rz_EnabledOptions.Ectoplasm then
           if (RootPart.Position - Target.Position).Magnitude <= 200 then
            RootPart.CFrame = Target
            RootPart.CanCollide = false
          else
            RootPart.CanCollide = false
            BodyPosition.Position = Target.Position
          end
       elseif _ENV.rz_EnabledOptions.DungeonKill then
       if (RootPart.Position - Target.Position).Magnitude <= 125 and not Enemy:GetAttribute("RaidBoss") then
            RootPart.CFrame = Target
            RootPart.CanCollide = false
          else
            RootPart.CanCollide = false
            BodyPosition.Position = Target.Position
          end
         else
          if (RootPart.Position - Target.Position).Magnitude <= 225 then
            RootPart.CFrame = Target
            RootPart.CanCollide = false
          else
            RootPart.CanCollide = false
            BodyPosition.Position = Target.Position
          end
      end
        end;task.wait()
      end
      if Enemy and Enemy:HasTag(BRING_TAG) then Enemy:RemoveTag(BRING_TAG) end
end
		
		local function KillAura(Enemy)
			local Humanoid = Enemy:FindFirstChild("Humanoid")
			local RootPart = Enemy:FindFirstChild("HumanoidRootPart")
			
	       sethiddenproperty(game.Players.LocalPlayer, "SimulationRadius", 112412400000)
           sethiddenproperty(game.Players.LocalPlayer, "MaxSimulationRadius", 112412400000)

			if Humanoid and RootPart then
				Humanoid.Health = 0
				task.wait()
				Enemy:RemoveTag(KILLAURA_TAG)
			end
		end
		
		for _, Enemy in CollectionService:GetTagged("BasicMob") do NewEnemyAdded(Enemy) end
		table.insert(Connections, CollectionService:GetInstanceAddedSignal("BasicMob"):Connect(NewEnemyAdded))
		
		table.insert(Connections, CollectionService:GetInstanceAddedSignal(KILLAURA_TAG):Connect(KillAura))
		table.insert(Connections, CollectionService:GetInstanceAddedSignal(BRING_TAG):Connect(Bring))
		
		return EnemiesModule
	end)()

        local ItemReplicationService = require(game:GetService("ReplicatedStorage"):WaitForChild("ItemReplicationService"))
		local ItemConfig = require(game:GetService("ReplicatedStorage"):WaitForChild("ItemConfig"))
		GetInventoryItems = function()local n={};local L=require(game:GetService("ReplicatedStorage"):WaitForChild("ItemReplicationService")).KEYS;for U,U in  ItemReplicationService :GetItems(L.QUANTITY)do if U.Value and U.Value>0 then local w,y=pcall(function()return  ItemConfig .match(U.ItemId):unwrap();end);if w and y and y.Display then local w,S=y.Display.Category,y.Index and y.Index.StorageKey;local K,R=if w=="Blox Fruit"then S or y.Display.Name or"ItemId_"..U.ItemId else y.Display.Name or S or"ItemId_"..U.ItemId, ItemReplicationService :ReadItem(L.MASTERY,U.ItemId,U.NetworkedUID)or 0;table.insert(n,{Name=K,Type=w,Count=U.Value,Mastery=R,ItemId=U.ItemId,UID=U.NetworkedUID});end;end;end;return n;end

Module.Inventory = (function()
    local Inventory = {
        Unlocked = setmetatable({}, {
            __index = function()
                return false
            end
        }),
        Mastery = setmetatable({}, {
            __index = function()
                return 0
            end
        }),
        Count = setmetatable({}, {
            __index = function()
                return 0
            end
        }),
        MasteryRequirements = {},
        Items = {}
    }
    function Inventory:UpdateItem(item)
        if type(item) ~= "table" or not item.Name then
            return
        end
        if item.Type == "Wear" then
            item.Type = "Accessory"
        end
        local name = item.Name
        self.Items[name] = item
        self.Unlocked[name] = true
        if item.Count ~= nil then
            self.Count[name] = tonumber(item.Count) or 0
        end
        if item.Mastery ~= nil then
            self.Mastery[name] = tonumber(item.Mastery) or 0
        end
        if item.MasteryRequirements ~= nil then
            self.MasteryRequirements[name] = item.MasteryRequirements
        end
    end
    function Inventory:Add()
        local NewItems = GetInventoryItems() self.Items = {} for _, item in pairs(NewItems) do self:UpdateItem(item) end
    end
    function Inventory:Refresh()
    local NewItems = GetInventoryItems()
    local CurrentItems = {}
    for _, item in pairs(NewItems) do
        if type(item) == "table" and item.Name then
            CurrentItems[item.Name] = true
            self:UpdateItem(item)
        end
    end
    for name in pairs(self.Items) do
        if not CurrentItems[name] then
            self.Items[name] = nil
            self.Unlocked[name] = nil
            self.Count[name] = nil
            self.Mastery[name] = nil
            self.MasteryRequirements[name] = nil
        end
    end
end
Inventory:Add()
    task.spawn(function()
        while task.wait(1) do
            pcall(function()
                Inventory:Refresh()
            end)
        end
    end)
    local function OnClientEvent(Method, ...)
        if Method == "Notify" then
            Module.Signals.Notify:Fire(...)
        end
    end
    task.spawn(function()table.insert(Connections,CommE.OnClientEvent:Connect(OnClientEvent))end)
    return Inventory
end)()

   Module.FastAttack = (function()
		local FastAttack = {
			Distance = 55,
			attackMobs = true,
			attackPlayers = true,
			Equipped = nil,
			Debounce = 0,
			ComboDebounce = 0,
			ShootDebounce = 0,
			M1Combo = 0,
			
			Overheat = {
				["Dragonstorm"] = {
					MaxOverheat = 3,
					Cooldown = 0,
					TotalOverheat = 0,
					Distance = 300,
					Shooting = false
				}
			},
			ShootsPerTarget = {
				["Dual Flintlock"] = 2
			},
			SpecialShoots = {
				["Skull Guitar"] = "TAP",
				["Bazooka"] = "Position",
				["Cannon"] = "Position",
				["Dragonstorm"] = "Overheat"
			},
           FruitClick = {
				["Blade-Blade"] = true,
				["Gas-Gas"] = true
			},
			NormalClickFruits = {
				["Light-Light"] = true,
				["Ice-Ice"] = true
			}
		}
		
		local RE_RegisterAttack: RemoteEvent = Net:WaitForChild("RE/RegisterAttack")
		local RE_ShootGunEvent: RemoteEvent = Net:WaitForChild("RE/ShootGunEvent")
		local RE_RegisterHit: RemoteEvent = Net:WaitForChild("RE/RegisterHit")
		local Events: Folder = ReplicatedStorage:WaitForChild("Events")
		
		local SUCCESS_FLAGS, COMBAT_REMOTE_THREAD = pcall(function()
			return require(Modules.Flags).COMBAT_REMOTE_THREAD or false
		end)
		
		local SUCCESS_SHOOT, SHOOT_FUNCTION = pcall(function()
			return getupvalue(require(ReplicatedStorage.Controllers.CombatController).Attack, 9)
		end)
		
		local HIT_FUNCTION; task.defer(function()			
			if getsenv then
					HIT_FUNCTION = (getmenv or getsenv)(Net)._G.SendHitsToServer
				end
		end)

        local IsAlive = Module.IsAlive
		
		FastAttack.ShootsFunctions = {
			["Skull Guitar"] = function(self: FastAttack, Equipped: Tool, Position: Vector3): (nil)
                local humanoid = Equipped.Parent:FindFirstChildOfClass("Humanoid")
                for _, v in ipairs(humanoid:GetChildren()) do if v:IsA("RemoteFunction") and v.Name == "" then v:InvokeServer("TAP", Position) end end
			end
		}
		
		local CurrentBladeHits = {};
		local MyRootPartPosition = nil;
		local NoAttackBelowTool = nil;
		local NoAttackBelowDebounce = 0;
		local BelowHealthPercent = 0;        
		
		local function ExpandsHitBox(Enemies: { table }): (nil)
			for i = 1, #Enemies do
				Enemies[i][2].Size = Vector3.one * 50
				Enemies[i][2].Transparency = 1
			end
		end
		
		local function CheckStun(ToolTip: string, Character: Character, Humanoid: Humanoid): boolean
			-- local Stun = Character:FindFirstChild("Stun")
			-- local Busy = Character:FindFirstChild("Busy")
			
			if Humanoid.Sit and (ToolTip == "Sword" or ToolTip == "Melee" or ToolTip == "Gun") then
				return false
			-- elseif Stun and Stun.Value > 0 then {{ or Busy and Busy.Value }}
			--	 return false
			end
			
			return true
		end
		
		local function NewBladeHit(RootPart: BasePart, Character: Model): (nil)
			table.insert(CurrentBladeHits, { Character, RootPart })
		end
		
		local function GetMaxHits(Character)
			if Character:FindFirstChild("HumanoidRootPart") and Character.HumanoidRootPart:FindFirstChild("Buddha") then
				return 10
			end
			return 1
		end
		
		local function ProcessSeaEventsHits(Distance)
			for _, SeaBeast in SeaBeasts:GetChildren() do
				local BasePart = SeaBeast:FindFirstChildOfClass("MeshPart")
				
				if IsAlive(SeaBeast) and BasePart and (MyRootPartPosition - BasePart.Position).Magnitude < Distance then
					NewBladeHit(BasePart, SeaBeast)
				end
			end
			
			for _, Boat in Enemies:GetChildren() do
                if not Boat:GetAttribute("IsBoat") then continue end
				local BasePart = Boat:FindFirstChildOfClass("MeshPart")
				
				if IsAlive(Boat) and BasePart and (MyRootPartPosition - BasePart.Position).Magnitude < Distance then
					NewBladeHit(BasePart, Boat)
				end
			end
		end
		
		local function CanChangeGunTarget(Target, Enemy)
			if Enemy.Parent == SeaBeasts then
				return true
             elseif Target.Parent ~= SeaBeasts and Enemy:GetAttribute("RaidBoss") then
              return true
            elseif Target.Parent ~= SeaBeasts and not Enemy:GetAttribute("IsBoat") then
               return true
			elseif Target.Parent ~= SeaBeasts and Enemy:GetAttribute("IsBoat") then
				return true
			end
			
			return false
		end
		
		local function ConvertToGunHits()
			local Target, Hitbox;
			
			for index = 1, #CurrentBladeHits do
				local Hit = CurrentBladeHits[index]
				
				if not Target or CanChangeGunTarget(Target, Hit[1]) then
					Hitbox, Target = Hit[2], Hit[1];
				end
			end
			
			CurrentBladeHits = { Hitbox, math.random() }
			return Hitbox.Position, Hitbox;
		end
		
    	local function ProcessHits(List: Folder, Equipped: Tool, Distance: number): (nil)
			local MyCharacter = Player.Character;
			local Targets = List:GetChildren();
			local MaxHits = GetMaxHits(MyCharacter) + 1;
			
			for i = 1, #Targets do
				if #CurrentBladeHits >= MaxHits then break end
				
				local Character = Targets[i]
				if Character == MyCharacter or Character:GetAttribute("IsBoat") or not IsAlive(Character) then continue end
				local RootPart = Character.PrimaryPart
				
				if (tick() - NoAttackBelowDebounce) <= 1 then
					local Humanoid = Character.Humanoid
					
					if Humanoid.Health / Humanoid.MaxHealth * 100 <= BelowHealthPercent then
						continue
					end
				end
				
               local TargetPlayer = game:GetService("Players"):GetPlayerFromCharacter(Character)
               if RootPart and (Character.Parent ~= Characters or (TargetPlayer and CheckPlayerAlly(TargetPlayer))) then
					local Hitbox = RootPart
					
					if Hitbox and (MyRootPartPosition - RootPart.Position).Magnitude <= Distance then
						NewBladeHit(Hitbox, Character)
					end
				end
			end
		end
	
		function FastAttack:DontAttackBelowPercent(Percent: number): boolean
			if SUCCESS_FLAGS and not COMBAT_REMOTE_THREAD or SUCCESS_FLAGS and COMBAT_REMOTE_THREAD and HIT_FUNCTION then
				BelowHealthPercent = Percent
				NoAttackBelowDebounce = tick()
				
				return true
			end
			
			return false
		end
		
		function FastAttack:UpdateBladeHits(Distance: number?, Anything: boolean?, SeasEvents: boolean?): (nil)
			Distance = Distance or self.Distance;
			CurrentBladeHits = {};
			
			if Anything or self.attackMobs then
				ProcessHits(Enemies, self.Equipped, Distance)
			end
			if Anything or self.attackPlayers then
				ProcessHits(Characters, self.Equipped, Distance)
			end
			if SeasEvents then
				ProcessSeaEventsHits(Distance, self.Equipped)
			end
		end
		
		function FastAttack:ShootInTarget(TargetPosition: Vector3): (nil)
			local Equipped = IsAlive(Player.Character) and Player.Character:FindFirstChildOfClass("Tool")
			
			if Equipped and Equipped.ToolTip == "Gun" then
				if Equipped:FindFirstChild("Cooldown") and (tick() - self.ShootDebounce) >= Equipped.Cooldown.Value then
					if self.ShootsFunctions[Equipped.Name] then
						return self.ShootsFunctions[Equipped.Name](self, Equipped, TargetPosition)
					end
					
					if SUCCESS_SHOOT and SHOOT_FUNCTION then
						local ShootType = self.SpecialShoots[Equipped.Name] or "Normal"
						
						if ShootType == "Position" or (ShootType == "TAP" and Equipped:FindFirstChild("RemoteEvent")) then
							Equipped:SetAttribute("LocalTotalShots", (Equipped:GetAttribute("LocalTotalShots") or 0) + 1)
							GunValidator:FireServer(self:GetValidator2())
							
							if ShootType == "TAP" then
							  local humanoid = Equipped.Parent:FindFirstChildOfClass("Humanoid")
                              for _, v in ipairs(humanoid:GetChildren()) do if v:IsA("RemoteFunction") and v.Name == "" then v:InvokeServer("TAP", Position) end end
							else
								RE_ShootGunEvent:FireServer(TargetPosition)
							end
							
							self.ShootDebounce = tick()
						end
					else
						VirtualInputManager:SendMouseButtonEvent(0, 0, 0, true, game, 1);task.wait(0.05)
						VirtualInputManager:SendMouseButtonEvent(0, 0, 0, false, game, 1);task.wait(0.05)
						self.ShootDebounce = tick()
					end
				end
			end
		end
		
		function FastAttack:GetClosestEnemy(Distance: number?): (nil)
			self:UpdateBladeHits(Distance, true)
			
			local Distance, Closest = math.huge
			
			for i = 1, #CurrentBladeHits do
				local Magnitude = (MyRootPartPosition - CurrentBladeHits[i][2].Position).Magnitude
				
				if Magnitude <= Distance then
					Distance, Closest = Magnitude, CurrentBladeHits[i][2]
				end
			end
			
			return Closest
		end
		
		function FastAttack:GetCombo(): number
			local Combo = if tick() - self.ComboDebounce <= 0.4 then self.M1Combo else 0
			Combo = if Combo >= 4 then 1 else Combo + 1
			
			self.ComboDebounce = tick()
			self.M1Combo = Combo
			
			return Combo
		end
		
		function FastAttack:UseFruitM1(Character: Character, Equipped: Tool, Combo: number): (nil)
			local MyPosition = Character.Humanoid.RootPart.Position
			local _Enemies = Enemies:GetChildren()
			
			for i = 1, #_Enemies do
				local Enemy = _Enemies[i]
				local RootPart = IsAlive(Enemy) and Enemy.PrimaryPart
				
				if RootPart and (RootPart.Position - MyPosition).Magnitude <= 55 then
					Equipped.LeftClickRemote:FireServer((RootPart.Position - MyPosition).Unit, Combo)
				end
			end
		end
		
		function FastAttack:UseNormalClick(Cooldown: number): (nil)
		    MyRootPartPosition = Player.Character.Humanoid.RootPart.Position;
			self:UpdateBladeHits()			
			
			if #CurrentBladeHits > 0 then
				local PrimaryRootPart = table.remove(CurrentBladeHits)[2]
				
				if SUCCESS_FLAGS and COMBAT_REMOTE_THREAD and HIT_FUNCTION then
					RE_RegisterAttack:FireServer(Cooldown)
					HIT_FUNCTION(PrimaryRootPart, CurrentBladeHits)
				elseif SUCCESS_FLAGS and not COMBAT_REMOTE_THREAD then
					RE_RegisterAttack:FireServer(Cooldown)
					RE_RegisterHit:FireServer(PrimaryRootPart, CurrentBladeHits)
				else
					table.insert(CurrentBladeHits, { Enemy, PrimaryRootPart })
					ExpandsHitBox(CurrentBladeHits)
					
					VirtualInputManager:SendMouseButtonEvent(0, 0, 0, true, game, 1);task.wait(0.05)
					VirtualInputManager:SendMouseButtonEvent(0, 0, 0, false, game, 1)
				end
			end
		end
		
     function FastAttack:GetValidator2()
    local v53 = getupvalue(SHOOT_FUNCTION, 13) -- a
    local v54 = getupvalue(SHOOT_FUNCTION, 14) -- 798405
    local v55 = getupvalue(SHOOT_FUNCTION, 15) -- b
    local v56 = getupvalue(SHOOT_FUNCTION, 16) -- 727595
    local v57 = getupvalue(SHOOT_FUNCTION, 17) -- 1048576 + shared("")
    local v58 = getupvalue(SHOOT_FUNCTION, 18) -- 1099511627776
    local v59 = getupvalue(SHOOT_FUNCTION, 19) -- counter

    local v93 = v53 * v54
    local v96 = (v55 * v54 + v53 * v56) % v57

    v96 = (v96 * v57 + v93) % v58
    v55 = math.floor(v96 / v57)
    v53 = v96 - v55 * v57
    v59 = v59 + 1

    setupvalue(SHOOT_FUNCTION, 13, v53)
    setupvalue(SHOOT_FUNCTION, 15, v55)
    setupvalue(SHOOT_FUNCTION, 19, v59)

    return math.floor(v96 / v58 * 16777215), v59
end

    local function IsValidTarget(Target)
	if not (Target and Target.Parent) then return false end
	if IsAlive(Target.Parent) then
		return true
	end
	if Target:FindFirstChild("Health") and Target.Health.Value > 0 then
		return true
	end
	return false
end

function FastAttack:ShootWithValidation(Position, Targets)
	local Equipped = Player.Character and Player.Character:FindFirstChildOfClass("Tool")
	if not Equipped then return end
	if Equipped.ToolTip ~= "Gun" then return end
	Equipped:SetAttribute("LocalTotalShots",(Equipped:GetAttribute("LocalTotalShots") or 0) + 1)
	GunValidator:FireServer(self:GetValidator2())
	if Targets then
		RE_ShootGunEvent:FireServer(Position, Targets)
	else
		RE_ShootGunEvent:FireServer(Position)
	end
end

function FastAttack:HandleOverheat(Equipped, Data)
	if Data.Shooting then return end
   if workspace:FindFirstChild("SeaBeasts") then
		for _, v in pairs(workspace.SeaBeasts:GetChildren()) do
			if v:IsA("Model") and string.find(v.Name,"SeaBeast") then
				seaBeast = v
				break
			end
		end
      for _, v in pairs(workspace.SeaBeasts:GetChildren()) do
			if v:IsA("Model") and not string.find(v.Name,"SeaBeast") then
				levi = v
				break
			end
		end
	end
	if seaBeast then
		self:UpdateBladeHits(500, false, true)
    elseif levi then
     self:UpdateBladeHits(2000, false, true)
	else
		self:UpdateBladeHits(Data.Distance, false, true)
	end
	if #CurrentBladeHits == 0 then return end
	local Position, PrimaryPart = ConvertToGunHits()
	local Target = PrimaryPart
	if not IsValidTarget(Target) then return end
	Data.Shooting = true
	while Equipped and Equipped.Parent == Player.Character and Data.TotalOverheat < Data.MaxOverheat do
		if not IsValidTarget(Target) then task.wait() break end
		self:ShootWithValidation(Target.Position, { Target })
		Data.TotalOverheat += task.wait(Data.Cooldown)
	end
	while Data.TotalOverheat > 0 do
		Data.TotalOverheat = math.clamp(Data.TotalOverheat - task.wait(), 0, Data.MaxOverheat)
	end
	Data.Shooting = false
end

function FastAttack:HandleNormal(Equipped)
	self:UpdateBladeHits(100, false, true)
	if #CurrentBladeHits == 0 then return end
	local Position, PrimaryPart = ConvertToGunHits()
	if not (PrimaryPart and PrimaryPart.Parent) then return end
	local shoots = self.ShootsPerTarget[Equipped.Name] or 1
	for _ = 1, shoots do
		self:ShootWithValidation(Position, CurrentBladeHits)
	end
end

function FastAttack:HandlePositionOrTap(Equipped)
	local Target = self:GetClosestEnemy(100)
	if not IsValidTarget(Target) then return end
	if self.ShootsFunctions[Equipped.Name] then
		return self.ShootsFunctions[Equipped.Name](self, Equipped, Target.Position)
	end
	self:ShootWithValidation(Target.Position)
end

function FastAttack:UseGunShoot(Character, Equipped)
	if not Equipped.Enabled then return end	
	MyRootPartPosition = Player.Character.Humanoid.RootPart.Position;
	local ShootType = self.SpecialShoots[Equipped.Name] or "Normal"
	if ShootType == "Overheat" then
		local Data = self.Overheat[Equipped.Name]
		return self:HandleOverheat(Equipped, Data)	
	elseif ShootType == "Normal" then
		return self:HandleNormal(Equipped)	
	elseif ShootType == "Position" or (ShootType == "TAP" and Equipped:FindFirstChild("RemoteEvent")) then
		return self:HandlePositionOrTap(Equipped)
	end
end
		
	 	function FastAttack.attack()
            if not Settings.AutoClick or (tick() - Module.AttackCooldown) <= 1 then return end
			if not IsAlive(Player.Character) then return end
			
			local self = FastAttack;
			local Character = Player.Character;
			local Humanoid = Character.Humanoid;
			
			local Equipped = Character:FindFirstChildOfClass("Tool")
			local ToolTip = Equipped and Equipped.ToolTip
			
			if not Equipped or (ToolTip ~= "Gun" and ToolTip ~= "Melee" and ToolTip ~= "Blox Fruit" and ToolTip ~= "Sword") then
				return nil
			end
			
			local Cooldown = Equipped:FindFirstChild("Cooldown") and Equipped.Cooldown.Value or 0.3;
			
			if (tick() - self.Debounce) >= Cooldown and CheckStun(ToolTip, Character, Humanoid) then
				local Combo = self:GetCombo();
				if Combo >= 4 then Cooldown += 0.05 end;
				
				self.Equipped = Equipped;
				self.Debounce = if Combo >= 4 and ToolTip ~= "Gun" then tick() + (Cooldown / 2) else tick();
				
				if ToolTip == "Blox Fruit" and not self.NormalClickFruits[Equipped.Name] and not self.FruitClick[Equipped.Name] then
					if Equipped:FindFirstChild("LeftClickRemote") then
						Equipped.LeftClickRemote:FireServer(Vector3.new(0.01,-500,0.01),1)
					end
                elseif ToolTip == "Blox Fruit" and self.FruitClick[Equipped.Name] then
					if Equipped:FindFirstChild("LeftClickRemote") then
						self:UseFruitM1(Character, Equipped, Combo)
					end
				elseif ToolTip == "Gun" then
					if SUCCESS_SHOOT and SHOOT_FUNCTION then
						self:UseGunShoot(Character, Equipped)
					end
	    	  elseif ToolTip == "Melee" or ToolTip == "Sword" or self.NormalClickFruits[Equipped.Name] then
		      	self:UseNormalClick(Cooldown)
				end
			end
		end

       table.insert(Connections, Stepped:Connect(FastAttack.attack))

		return FastAttack
	end)()

	Module.RaidList = (function()
		local Success, RaidModule = pcall(require, ReplicatedStorage:WaitForChild("Raids"))
		
		if not Success or type(RaidModule) ~= "table" then
			return {
				"Phoenix", "Dough", "Flame", "Ice", "Quake", "Light";
				"Dark", "Spider", "Rumble", "Magma", "Buddha", "Sand";
			}
		end
		
		local AdvancedRaids = RaidModule.advancedRaids or {}
		local NormalRaids = RaidModule.raids or {}
		local RaidList = {}
		
		for i = 1, #AdvancedRaids do table.insert(RaidList, AdvancedRaids[i]) end
		for i = 1, #NormalRaids do table.insert(RaidList, NormalRaids[i]) end
		
		return RaidList
	end)()
	
	Module.Tween = (function()
		local BodyVelocity = Instance.new("BodyVelocity")
		BodyVelocity.Velocity = Vector3.zero
		BodyVelocity.MaxForce = Vector3.new(math.huge, math.huge, math.huge)
		BodyVelocity.P = 1000
		
		if _ENV.tween_bodyvelocity then
			_ENV.tween_bodyvelocity:Destroy()
		end
		
		_ENV.tween_bodyvelocity = BodyVelocity
		
		local IsAlive = Module.IsAlive
		local CanRemoveTag = false
		
		local BaseParts, CanCollideObjects, CanTouchObjects = {}, {}, {} do
			local function AddObjectToBaseParts(Object)
				if Object:IsA("BasePart") and (Object.CanCollide or Object.CanTouch) then
					table.insert(BaseParts, Object)
					
					if Object.CanCollide then CanCollideObjects[Object] = true end
					if Object.CanTouch then CanTouchObjects[Object] = true end
				end
			end
			
			local function RemoveObjectsFromBaseParts(BasePart)
				local index = table.find(BaseParts, BasePart)
				
				if index then
					table.remove(BaseParts, index)
				end
			end
			
			local function NewCharacter(Character)
				table.clear(BaseParts)
				
				for _, Object in ipairs(Character:GetDescendants()) do AddObjectToBaseParts(Object) end
				Character.DescendantAdded:Connect(AddObjectToBaseParts)
				Character.DescendantRemoving:Connect(RemoveObjectsFromBaseParts)
				
				Character:WaitForChild("Humanoid", 9e9).Died:Wait()
				table.clear(BaseParts)
			end
			
			table.insert(Connections, Player.CharacterAdded:Connect(NewCharacter))
			task.spawn(NewCharacter, Player.Character)
		end
		
		local function NoClipOnStepped(Character)
			if not IsAlive(Character) then return end
			
			if _ENV.OnFarm and not Player:HasTag("Teleporting") then
				Player:AddTag("Teleporting")
				CanRemoveTag = true
			elseif not _ENV.OnFarm and CanRemoveTag and Player:HasTag("Teleporting") then
				Player:RemoveTag("Teleporting")
				CanRemoveTag = false
			end
			
			if _ENV.OnFarm then
				for i = 1, #BaseParts do
					local BasePart = BaseParts[i]
					local CanTouchValue = if (tick() - Module.RemoveCanTouch) <= 1 then false else true
					
					if CanTouchObjects[BasePart] and BasePart.CanTouch ~= CanTouchValue then
						BasePart.CanTouch = CanTouchValue
					end
					if CanCollideObjects[BasePart] and BasePart.CanCollide then
						BasePart.CanCollide = false
					end
				end
			elseif Character.PrimaryPart and (not Character.PrimaryPart.CanCollide or not Character.PrimaryPart.CanTouch) then
				for i = 1, #BaseParts do
					local BasePart = BaseParts[i]
					
					if CanCollideObjects[BasePart] then
						BasePart.CanCollide = true
					end
					if CanTouchObjects[BasePart] then
						BasePart.CanTouch = true
					end
				end
			end
		end
		
		local function UpdateVelocityOnStepped(Character)
			local RootPart = Character and Character:FindFirstChild("UpperTorso")
			local Humanoid = Character and Character:FindFirstChild("Humanoid")
			local BodyVelocity = _ENV.tween_bodyvelocity
			
			if _ENV.OnFarm and RootPart and Humanoid and Humanoid.Health > 0 then
				if BodyVelocity.Parent ~= RootPart then
					BodyVelocity.Parent = RootPart
				end
			else
				if BodyVelocity.Parent then
					BodyVelocity.Parent = nil
				end
			end
			
			if BodyVelocity.Velocity ~= Vector3.zero and (not Humanoid or not Humanoid.SeatPart or not _ENV.OnFarm) then
				BodyVelocity.Velocity = Vector3.zero
			end
		end
		
		table.insert(Connections, Stepped:Connect(function()
			local Character = Player.Character
			UpdateVelocityOnStepped(Character)
			NoClipOnStepped(Character)
		end))
		
		return BodyVelocity
	end)()

  Module.Hooking = (function()
		local Hooking = {
			Skills = CreateDictionary({ "Z", "X", "C", "V", "F" }, true),
			ClosestsEnemies = {}
		}
		
		local Enabled = _ENV.rz_EnabledOptions
		local Debounce = Module.Debounce
		local IsAlive = Module.IsAlive
		
		local function GetNextTarget(Mode: string, ClosestList: boolean): any?
			if (tick() - Debounce.TargetDebounce) <= 2 or _ENV[Mode] then
				return if ClosestList then Hooking.ClosestsEnemies else Hooking.ClosestsEnemies.Closest
			end
		end
		
		function Hooking:SetTarget(RootPart: BasePart, Character: Model?, IsEnemy: boolean?): (nil)
			table.clear(self.ClosestsEnemies)
			self.ClosestsEnemies.Closest = RootPart
			Debounce.TargetDebounce = tick()
			
			if IsEnemy then
				for _, Enemy in ipairs(Module.Enemies:GetTagged(Character.Name)) do
					if Enemy ~= Character and Enemy:FindFirstChild("UpperTorso") then
						table.insert(self.ClosestsEnemies, Enemy.UpperTorso)
					end
				end
			end
		end

		if identifyexecutor() == "Delta" then
		function Hooking.UpdateClosests()
			local SmoothDebounce = Settings.SmoothMode and 0.5 or 0.25
			
			if (tick() - Debounce.TargetDebounce) <= 2 or (tick() - Debounce.UpdateDebounce) <= SmoothDebounce then
				return nil
			end
			
			Debounce.UpdateDebounce = tick()
			local Equipped = IsAlive(Player.Character) and Player.Character:FindFirstChildOfClass("Tool")
			
			if Equipped and Equipped.ToolTip then
				local ClosestsEnemies = Hooking.ClosestsEnemies
				table.clear(ClosestsEnemies)
				
				local Position = Player.Character:GetPivot().Position
				
				local Players = Players:GetPlayers()
				local Enemies = Enemies:GetChildren()
				
				local Distance = 900
				local ClosestsDistance = if Equipped.ToolTip == "Gun" then 120 else 60

               if not _G.NoAimPlayer then
				for i = 1, #Players do
					local __Player = Players[i]
					local Character = __Player.Character
					
					if Player ~= __Player and CheckPlayerAlly(__Player) and IsAlive(Character) then
						local UpperTorso = Character:FindFirstChild("UpperTorso")
						local Magnitude = UpperTorso and (UpperTorso.Position - Position).Magnitude
						
						if UpperTorso and Magnitude <= ClosestsDistance then
							table.insert(ClosestsEnemies, UpperTorso)
						end
						if UpperTorso and Magnitude <= Distance then
							ClosestsEnemies.Closest = UpperTorso
							Distance = if UpperTorso then Magnitude else Distance
						end
					end
				end
            end
				
				if not _G.NoAimMobs then
				for i = 1, #Enemies do
					local Enemy = Enemies[i]
					local UpperTorso = Enemy and Enemy:FindFirstChild("UpperTorso")
					
					if UpperTorso and IsAlive(Enemy) then
						local Magnitude = (UpperTorso.Position - Position).Magnitude
						
						if Magnitude <= ClosestsDistance then
							table.insert(ClosestsEnemies, UpperTorso)
						end
						if Magnitude <= Distance then
							Distance, ClosestsEnemies.Closest = Magnitude, UpperTorso
						end
					end
				end
			end
		end
    end
		
		task.defer(function()
			if _ENV.original_namecall then
				return nil
			end
			
			local old_namecall; old_namecall = hookmetamethod(game, "__namecall", function(self, ...)
				if string.lower(getnamecallmethod()) ~= "fireserver" then
					return old_namecall(self, ...)
				end
				
				local Name = self.Name
				
				if Name == "RE/ShootGunEvent" then
					local Position, Enemies = ...
					
					if typeof(Position) == "Vector3" and type(Enemies) == "table" then
						local ClosestList = GetNextTarget("AimBot_Gun", true)
						
						if ClosestList and #ClosestList > 0 then
							for i = 1, #ClosestList do
								local BasePart = ClosestList[i]
								
								if BasePart and (not Enemies[1] or (BasePart.Position - Enemies[1].Position).Magnitude <= 500) then
									table.insert(Enemies, BasePart)
								end
							end
							
							return old_namecall(self, Enemies[1].Position, Enemies)
						end
					end
				elseif Name == "RemoteEvent" then
					local v1, v2 = ...
					
					if typeof(v1) == "Vector3" and not v2 then
						local Target = GetNextTarget("AimBot_Skills")
						
						if Target then
							return old_namecall(self, Target.Position)
						end
					elseif v1 == "TAP" and typeof(v2) == "Vector3" then
						local Target = GetNextTarget("AimBot_Tap")
						
						if Target then
							return old_namecall(self, "TAP", Target.Position)
						end
					end
				end
				
				return old_namecall(self, ...)
			end)
			
			_ENV.original_namecall = old_namecall
		end)
		
		table.insert(Connections, Heartbeat:Connect(Hooking.UpdateClosests))
     end
		
		return Hooking
	end)()

  task.defer(function()
	 	local DeathEffect = require(WaitChilds(ReplicatedStorage, "EffectContainer", "Death"))
	 	local CameraShaker = require(WaitChilds(ReplicatedStorage, "Util", "CameraShaker"))
		if CameraShaker then
	 		CameraShaker:Stop()
	 	end
        if hookfunction then
 		hookfunction(DeathEffect, function(...) return ... end)
	 	end
	end)
	
	task.spawn(function()
		local SpawnLocations = Module.SpawnLocations
		local EnemyLocations = Module.EnemyLocations
		
		local function NewIslandAdded(Island)
			if Island.Name:find("Island") then
				Cached.RaidIsland = nil
			end
		end
		
		local function NewSpawn(Part)
			local EnemyName = GetEnemyName(Part.Name)
			EnemyLocations[EnemyName] = EnemyLocations[EnemyName] or {}
			
			local EnemySpawn = Part.CFrame + Vector3.new(0, 25, 0)
			SpawnLocations[EnemyName] = Part
			
			if not table.find(EnemyLocations[EnemyName], EnemySpawn) then
				table.insert(EnemyLocations[EnemyName], EnemySpawn)
			end
		end
		
		for _, Spawn in EnemySpawns:GetChildren() do NewSpawn(Spawn) end
		table.insert(Connections, EnemySpawns.ChildAdded:Connect(NewSpawn))
		table.insert(Connections, Locations.ChildAdded:Connect(NewIslandAdded))
	end)
end

function EnableBuso()
	local Character = Player.Character
	local IsAlive = Module.IsAlive(Character)
	
	if Settings.AutoBuso and IsAlive and not Character:FindFirstChild("HasBuso") then
		if Character:HasTag("Buso") then
			Module.FireRemote("Buso")
		elseif Money.Value >= 25e3 then
			Module.FireRemote("BuyHaki", "Buso")
		end
	end
end

function GetToolByName(Name)
	local Cached = Module.Cached.Tools[Name]
	local Character = Module.IsAlive(Player.Character) and Player.Character and Player:FindFirstChild("Backpack")

	if Cached and (Cached.Parent == Player.Character or Cached.Parent == Player.Backpack) then
		return Cached
	end
	
	if Character then
		local HasTool = Player.Character:FindFirstChild(Name) or Player.Backpack:FindFirstChild(Name)
		
		if HasTool then
			Module.Cached.Tools[Name] = HasTool
			return HasTool
		end
	end
end

function GetToolMastery(Name)
	local HasTool = GetToolByName(Name)
	return HasTool and HasTool:GetAttribute("Level") or 0
end

function GetToolTip(ToolTip, Folder)
	for _, Tool in Folder:GetChildren() do
		if Tool:IsA("Tool") and Tool.ToolTip == ToolTip then
			Module.Cached.Tools[`ToolTip_{ToolTip}`] = Tool
			return Tool
		end
	end
end

function VerifyToolTip(ToolTip)
	local Cached = Module.Cached.Tools[`ToolTip_{ToolTip}`]
	
	if Cached and (Cached.Parent == Player.Character or Cached.Parent == Player.Backpack) then
		return Cached
	end
	
	local Character = Module.IsAlive(Player.Character) and Player.Character
	
	return GetToolTip(ToolTip, Player.Backpack) or Character and GetToolTip(ToolTip, Character)
end

function VerifyTool(Name)
	return if GetToolByName(Name) then true else false
end

 return Module